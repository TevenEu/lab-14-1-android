package ec.yachay.steeven.lab14_1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 1;
    private ImageView preview;
    private TextView result;
    private ImageLabeler labeler;
    private int currentRequest;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        labeler = ImageLabeling.getClient(new ImageLabelerOptions.Builder()
                .setConfidenceThreshold(0.5f).build());
        ScrollView scroll = new ScrollView(this);
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setPadding(dp(22), dp(18), dp(22), dp(18));
        scroll.addView(screen);
        TextView title = new TextView(this);
        title.setText("Image Labelling");
        title.setTextSize(28);
        screen.addView(title);
        TextView author = new TextView(this);
        author.setText("Steeven Eugenio · Lab 14.1");
        screen.addView(author);

        preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        screen.addView(preview, new LinearLayout.LayoutParams(-1, dp(245)));
        Button choose = new Button(this);
        choose.setText("Choose an image");
        choose.setOnClickListener(v -> {
            Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            picker.addCategory(Intent.CATEGORY_OPENABLE);
            picker.setType("image/*");
            startActivityForResult(picker, PICK_IMAGE);
        });
        screen.addView(choose);
        result = new TextView(this);
        result.setTextSize(17);
        result.setText("Choose a photo to see its labels.");
        screen.addView(result);
        setContentView(scroll);
    }

    @Override
    protected void onActivityResult(int code, int status, Intent data) {
        super.onActivityResult(code, status, data);
        if (code != PICK_IMAGE || status != RESULT_OK || data == null || data.getData() == null) return;
        try (InputStream stream = getContentResolver().openInputStream(data.getData())) {
            InputImage image = InputImage.fromFilePath(this, data.getData());
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = Math.max(1, Math.max(image.getWidth(), image.getHeight()) / 900);
            Bitmap bitmap = BitmapFactory.decodeStream(stream, null, options);
            preview.setImageBitmap(bitmap);
            label(image);
        } catch (IOException | RuntimeException e) {
            currentRequest++;
            preview.setImageDrawable(null);
            result.setText("Could not open this image.");
        }
    }

    private void label(InputImage image) {
        int request = ++currentRequest;
        result.setText("Finding labels…");
        labeler.process(image).addOnSuccessListener(this, labels -> {
            if (request != currentRequest) return;
            StringBuilder text = new StringBuilder();
            for (ImageLabel label : labels) {
                text.append(String.format(Locale.US, "%s · %.1f%%%n", label.getText(), 100 * label.getConfidence()));
            }
            result.setText(labels.isEmpty() ? "No label reached 50% confidence." : text.toString().trim());
        }).addOnFailureListener(this, error -> {
            if (request == currentRequest) result.setText("Could not label this image. Choose another photo.");
        });
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        labeler.close();
        super.onDestroy();
    }
}
